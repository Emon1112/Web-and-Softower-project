const path = require("path");

module.exports = {
    outputDir: path.join(__dirname, "/foodDeliveryBackend/templates"),
    assetsDir: "../static/"
}